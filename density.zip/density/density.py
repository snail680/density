import pygame, sys, os

win_w = 1200
win_h = 670
BLACK = "#000000"
WHITE = "#ffffff"
clock = pygame.time.Clock()
fps = 30

ship_width = ship_height = win_w/120

# Classes
class Text:
    def __init__(self, size, text, xpos, ypos):
        self.font = pygame.font.SysFont("Britannic Bold", size)
        self.image = self.font.render(text, 1, WHITE)
        self.rect = self.image.get_rect()
        self.rect = self.rect.move(xpos, ypos)

class Ship(pygame.sprite.Sprite):
    def __init__(self, x, y, player):
        pygame.sprite.Sprite.__init__(self)
        self.player = player
        self.speed = 5
        self.image = pygame.Surface((ship_width, ship_height)).convert()
        self.rect = pygame.Rect(x, y, ship_width, ship_height)
        self.rect = self.rect.move(x, y)
"""
    def update(self):
        key = pygame.key.get_pressed()

        if self.player == ‘left’:
            if key[pygame.K_w]:
                self.rect.y -= self.speed
"""

def main():
    # Initialize variables
    title = Text(150, "Density", win_w / 2 - 190, win_h / 2 - 100)
    subtitle = Text(75, "--Click Here--", win_w / 2 - 160, win_h - 290)

    # Create Game Objects

    # Create Groups

    # Intro Loop
    intro = True
    while intro:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()

            # Keypresses
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    sys.exit()
                    
            screen.fill(BLACK)
            screen.blit(title.image, title)
            if pygame.time.get_ticks() % 1000 < 500:
                screen.blit(subtitle.image, subtitle)
            if pygame.event == pygame.MOUSEBUTTONDOWN:
                intro = False
                play = True

            clock.tick(fps)
            pygame.display.flip()

    # Game Loop
        while play == True:
            # Checks if window exit button pressed
            print("working")

            # Update Groups

            # Adding Pills

            # Print Groups

            # Limits frames per iteration of while loop
            clock.tick(fps)
            # Writes to main surface



if __name__ == "__main__":
    global screen
    pygame.display.set_caption("Density")
    screen = pygame.display.set_mode((win_w, win_h), pygame.SRCALPHA)
    screen.fill(BLACK)
    # Force static position of screen
    os.environ['SDL_VIDEO_CENTERED'] = '1'

    # Runs imported module
    pygame.init()

    main()
